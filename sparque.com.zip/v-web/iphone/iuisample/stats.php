
<!-- Sleep so users see the activity indicator -->
<?php sleep(2); ?>

<ul id="stats" title="Stats">
    <li><a href="#usage">Usage</a></li>
    <li><a href="#battery">Battery</a></li>
</ul>
    
<div id="usage" title="Usage" class="panel">
    <h2>Play Time</h2>
    <fieldset>
        <div class="row">
            <label>Years</label>
            <input type="text" value="2"/>
        </div>
        <div class="row">
            <label>Months</label>
            <input type="text" value="8"/>
        </div>
        <div class="row">
            <label>Days</label>
            <input type="text" value="27"/>
        </div>
    </fieldset>
</div>

<div id="battery" title="Battery" class="panel">
    <h2>Better recharge soon!</h2>
</div>
